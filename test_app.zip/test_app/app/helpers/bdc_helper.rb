module BdcHelper
end
