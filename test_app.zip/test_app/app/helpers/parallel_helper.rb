module ParallelHelper
end
